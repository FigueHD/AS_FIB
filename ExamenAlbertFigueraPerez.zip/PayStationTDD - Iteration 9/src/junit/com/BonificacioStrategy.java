package junit.com;

public interface BonificacioStrategy {
	
	public int calcularBonificacio(int timeBought) throws NoEsPotBonificar ;

}

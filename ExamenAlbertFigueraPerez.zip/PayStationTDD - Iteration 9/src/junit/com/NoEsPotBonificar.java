package junit.com;

public class NoEsPotBonificar extends Exception {
	public NoEsPotBonificar( String e ) { }	
}

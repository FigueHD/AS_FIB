package junit.com;

public class One2OneBonificacio implements BonificacioStrategy {

	@Override
	public int calcularBonificacio(int timeBought) {
		return 0;
	}

}
